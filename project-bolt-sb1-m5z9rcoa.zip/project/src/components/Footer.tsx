import { Instagram, Facebook, Linkedin, Youtube } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-gradient-to-b from-sky-900 to-sky-700 text-white py-10 lg:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Spalte 1: Kontaktdaten */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Kontaktdaten</h3>
            <p className="text-sm">
              Rechtsanwaltskanzlei Weber & Partner<br />
              Königsstraße 2<br />
              70173 Stuttgart
            </p>
          </div>

          {/* Spalte 2: Rechtsgebiete */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Rechtsgebiete</h3>
            <ul className="space-y-2">
              {['Arbeitsrecht', 'Baurecht', 'Mietrecht', 'Gewerbemietrecht', 'Immobilienrecht', 'Energierecht', 'Inkassorecht'].map((area) => (
                <li key={area}>
                  <Link to={`/rechtsgebiete/${area.toLowerCase()}`} className="text-sm hover:text-sky-200 transition-colors">
                    {area}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Spalte 3: Die Kanzlei */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Die Kanzlei</h3>
            <ul className="space-y-2">
              {[
                { text: 'Über uns', path: '/ueber-uns' },
                { text: 'Das Team', path: '/team' },
                { text: 'Karriere', path: '/karriere' },
                { text: 'Rückrufservice', path: '/rueckruf' },
                { text: 'Rechtsfrage stellen', path: '/rechtsfrage' },
                { text: 'Kostenlose Ersteinschätzung', path: '/ersteinschaetzung' },
                { text: 'Sitemap', path: '/sitemap' },
              ].map((link) => (
                <li key={link.text}>
                  <Link to={link.path} className="text-sm hover:text-sky-200 transition-colors">
                    {link.text}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Spalte 4: Kontakt & Social Media */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Wir sind für Sie da</h3>
            <p className="text-sm mb-4">
              Bundesweite Rufnummer:<br />
              <span className="font-bold text-lg">0711 6070280</span>
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#E1306C] transition-colors">
                <Instagram className="h-6 w-6" />
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#3b5998] transition-colors">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#0077B5] transition-colors">
                <Linkedin className="h-6 w-6" />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#FF0000] transition-colors">
                <Youtube className="h-6 w-6" />
              </a>
            </div>
          </div>

          {/* Spalte 5: Rechtliches */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Rechtliches</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/datenschutz" className="text-sm hover:text-sky-200 transition-colors">
                  Datenschutz
                </Link>
              </li>
              <li>
                <Link to="/impressum" className="text-sm hover:text-sky-200 transition-colors">
                  Impressum
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
}