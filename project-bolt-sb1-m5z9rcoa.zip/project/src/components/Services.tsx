import { Scale, Users, BookOpen, Building } from 'lucide-react';

const services = [
  {
    title: 'Zivilrecht',
    description: 'Umfassende Beratung und Vertretung in allen zivilrechtlichen Angelegenheiten.',
    icon: Scale
  },
  {
    title: 'Familienrecht',
    description: 'Kompetente Unterstützung bei familienrechtlichen Fragen und Konflikten.',
    icon: Users
  },
  {
    title: 'Arbeitsrecht',
    description: 'Professionelle Beratung für Arbeitgeber und Arbeitnehmer.',
    icon: BookOpen
  },
  {
    title: 'Immobilienrecht',
    description: 'Rechtliche Begleitung bei allen Immobilienangelegenheiten.',
    icon: Building
  }
];

export default function Services() {
  return (
    <div className="py-24 sm:py-32" id="leistungen">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center">
          <h2 className="text-base font-semibold leading-7 text-sky-600">Unsere Expertise</h2>
          <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Leistungsübersicht
          </p>
          <p className="mt-6 text-lg leading-8 text-gray-600">
            Wir bieten Ihnen professionelle rechtliche Unterstützung in verschiedenen Bereichen des deutschen Rechts.
          </p>
        </div>
        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-4">
            {services.map((service) => (
              <div key={service.title} className="flex flex-col">
                <dt className="flex items-center gap-x-3 text-base font-semibold leading-7 text-gray-900">
                  <service.icon className="h-5 w-5 flex-none text-sky-600" aria-hidden="true" />
                  {service.title}
                </dt>
                <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-gray-600">
                  <p className="flex-auto">{service.description}</p>
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}