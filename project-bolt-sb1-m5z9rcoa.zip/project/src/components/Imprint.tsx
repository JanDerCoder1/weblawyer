import React from 'react';

export default function Imprint() {
  return (
    <div className="bg-white py-24 sm:py-32 mt-16">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-3xl">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl mb-8">Impressum</h1>
          
          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Angaben gemäß § 5 TMG</h2>
            <p className="text-gray-600 mb-4">
              Rechtsanwaltskanzlei Weber & Partner<br />
              Musterstraße 123<br />
              12345 Musterstadt
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Vertreten durch</h3>
            <p className="text-gray-600 mb-4">
              Dr. Michael Weber<br />
              Anna Schmidt<br />
              Thomas Müller
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Kontakt</h2>
            <p className="text-gray-600 mb-4">
              Telefon: +49 (0) 123 456789<br />
              Telefax: +49 (0) 123 456788<br />
              E-Mail: info@weber-partner.de
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Berufsbezeichnung und berufsrechtliche Regelungen</h2>
            <p className="text-gray-600 mb-4">
              Berufsbezeichnung: Rechtsanwälte (verliehen in der Bundesrepublik Deutschland)
            </p>
            <p className="text-gray-600 mb-4">
              Zuständige Rechtsanwaltskammer:<br />
              Rechtsanwaltskammer München<br />
              Tal 33<br />
              80331 München
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Berufsrechtliche Regelungen</h2>
            <p className="text-gray-600 mb-4">
              • Bundesrechtsanwaltsordnung (BRAO)<br />
              • Berufsordnung für Rechtsanwälte (BORA)<br />
              • Rechtsanwaltsvergütungsgesetz (RVG)
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Streitschlichtung</h2>
            <p className="text-gray-600 mb-4">
              Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit: 
              https://ec.europa.eu/consumers/odr/.<br />
              Unsere E-Mail-Adresse finden Sie oben im Impressum.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}