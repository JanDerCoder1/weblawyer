import { ClipboardList, Phone, HandshakeIcon } from 'lucide-react';

const steps = [
  {
    name: 'Formular ausfüllen oder im Chat nach einem Termin fragen',
    description: 'Beschreiben Sie Ihr Anliegen kurz und geben Sie Ihre Kontaktdaten an.',
    icon: ClipboardList
  },
  {
    name: 'Kostenlose Ersteinschätzung',
    description: 'Nachdem Sie nach einer Ersteinschätzung gefragt habe, erhalten Sie einen Rückruf. Im Austausch mit einem Anwalt können Sie Ihr Problem oder Anliegen genau beschreiben. Wir werden Ihnen dann mögliche ',
    icon: Phone
  },
  {
    name: 'Mandatierung',
    description: 'Sie haben sich dafür Entschieden mit uns zusammenzuarbeiten? Sie entscheiden in welcher Art und in welchem Umfang die Zusammenarbeit stattfinden soll.',
    icon: HandshakeIcon
  }
];

export default function Process() {
  return (
    <div className="bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center">
          <h2 className="text-base font-semibold leading-7 text-sky-600">Ein visuell unterstützter Prozess</h2>
          <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            In drei einfachen Schritten zum Recht
          </p>
          <p className="mt-6 text-lg leading-8 text-gray-600">
            Rechtsberatung sollte unkompliziert sein. Suchen Sie nicht alleine nach Antworten, sondern fragen Sie einfach einen Anwalt! Und das Beste daran: Es ist kostenlos und unverbindlich! Alles Weitere besprechen wir gemeinsam.n.
          </p>
        </div>
        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-10 lg:max-w-none lg:grid-cols-3 lg:gap-y-16">
            {steps.map((step) => (
              <div key={step.name} className="relative pl-16">
                <dt className="text-base font-semibold leading-7 text-gray-900">
                  <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-sky-600">
                    <step.icon className="h-6 w-6 text-white" aria-hidden="true" />
                  </div>
                  {step.name}
                </dt>
                <dd className="mt-2 text-base leading-7 text-gray-600">{step.description}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}