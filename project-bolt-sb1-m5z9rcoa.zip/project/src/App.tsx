import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import Process from './components/Process';
import PricingModels from './components/PricingModels';
import Team from './components/Team';
import Privacy from './components/Privacy';
import Imprint from './components/Imprint';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white flex flex-col">
        <Navbar />
        <div className="flex-grow">
          <Routes>
            <Route path="/" element={
              <main>
                <Hero />
                <Services />
                <Process />
                <PricingModels />
                <Team />
              </main>
            } />
            <Route path="/datenschutz" element={<Privacy />} />
            <Route path="/impressum" element={<Imprint />} />
          </Routes>
        </div>
        <Footer />
      </div>
    </Router>
  );
}

export default App;